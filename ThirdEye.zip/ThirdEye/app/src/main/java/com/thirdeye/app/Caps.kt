package com.thirdeye.app

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.CamcorderProfile
import android.os.Build
import android.os.Environment

/** What this phone can really do, read from Android instead of guessed. */
object Caps {
    private fun mgr(c: Context) = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private fun id(c: Context, facing: Int): String? = try {
        mgr(c).cameraIdList.firstOrNull { mgr(c).getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == facing }
    } catch (e: Exception) { null }

    fun dual(c: Context): Boolean = Build.VERSION.SDK_INT >= 30 && try { mgr(c).concurrentCameraIds.any { it.size >= 2 } } catch (e: Exception) { false }

    private fun line(c: Context, name: String, facing: Int): String {
        val id = id(c, facing) ?: return "$name: not found"
        val q = listOf("4K" to CamcorderProfile.QUALITY_2160P, "1080p" to CamcorderProfile.QUALITY_1080P, "720p" to CamcorderProfile.QUALITY_720P)
            .filter { try { CamcorderProfile.hasProfile(id.toInt(), it.second) } catch (e: Exception) { false } }.joinToString(" · ") { it.first }
        val fps = try { mgr(c).getCameraCharacteristics(id).get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)!!.maxOf { it.upper } } catch (e: Exception) { 30 }
        return "$name: $q · up to $fps fps"
    }

    fun summary(c: Context): String {
        val gb = Environment.getExternalStorageDirectory().usableSpace / 1e9
        return line(c, "Back", CameraCharacteristics.LENS_FACING_BACK) + "\n" + line(c, "Front", CameraCharacteristics.LENS_FACING_FRONT) +
            "\nBoth cameras at once: " + (if (dual(c)) "yes (720p)" else "not supported") +
            "\nFree storage: %.1f GB".format(gb) + (if (gb < 2) " (low)" else "")
    }
}
