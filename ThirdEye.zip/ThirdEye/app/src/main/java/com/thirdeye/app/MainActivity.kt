package com.thirdeye.app

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : LockedActivity() {
    private lateinit var live: LiquidView
    private lateinit var note: TextView
    private var tapped = false
    private val l: () -> Unit = { refresh() }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (Rec.missing(this).isEmpty()) go() else say("Camera and microphone access are needed to record.")
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Rec.app = applicationContext
        val root = FrameLayout(this)
        live = LiquidView(this).apply { reduce = Rec.prefs(this@MainActivity).getBoolean("reduce", false); setOnClickListener { onTap() } }
        root.addView(live, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        val title = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(Ui.txt(this@MainActivity, "◉", 24f, Ui.TEAL))
            addView(Ui.txt(this@MainActivity, "  Third Eye", 21f, Ui.ink(this@MainActivity), true))
        }
        root.addView(title, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { setMargins(Ui.dp(this@MainActivity, 24), Ui.dp(this@MainActivity, 24), 0, 0) })
        val gear = Ui.txt(this, "⚙", 28f, Ui.ink(this)).apply {
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 8))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        root.addView(gear, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { setMargins(0, Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 10), 0) })
        note = Ui.txt(this, "", 14f, Ui.sub(this)).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        root.addView(note, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM).apply { setMargins(Ui.dp(this@MainActivity, 32), 0, Ui.dp(this@MainActivity, 32), Ui.dp(this@MainActivity, 72)) })
        Ui.page(this, root)
        val pf = Rec.prefs(this)
        if (!pf.getBoolean("onb", false)) {
            pf.edit().putBoolean("onb", true).apply()
            android.app.AlertDialog.Builder(this).setTitle("Welcome to Third Eye")
                .setMessage("Tap the circle to record. Once recording really starts, Third Eye closes and keeps recording in the background. Your phone shows a notification and a camera indicator the whole time.\n\nOptional shortcuts: add the Third Eye tile to Quick Settings, or the widget to your home screen (Settings → Quick Start).\n\nOn Samsung: Settings → Battery → set Third Eye to Unrestricted for long recordings.")
                .setPositiveButton("Got it", null).show()
        }
    }

    override fun onStart() { super.onStart(); Rec.listeners.add(l) }
    override fun onStop() { Rec.listeners.remove(l); super.onStop() }
    override fun onResume() { super.onResume(); refresh() }

    private fun onTap() {
        if (Rec.prefs(this).getBoolean("haptic", true)) live.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        if (Rec.state == "recording") Rec.stop(this) else go()
    }

    private fun go() {
        val err = Rec.start(this)
        when {
            err == "perm" -> perms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
            err != null -> say(err)
            else -> { tapped = true; say("") }
        }
    }

    private fun refresh() {
        live.recording = Rec.state == "recording"; live.busy = Rec.state == "starting"; live.invalidate()
        if (Rec.state == "recording" && tapped) { tapped = false; finishAndRemoveTask() }   // only after real frames arrive
        if (Rec.state == "failed") { tapped = false; say(Rec.error ?: "Recording failed to start."); Rec.set("idle") }
    }

    private fun say(t: String) { note.text = t; note.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE }
}
