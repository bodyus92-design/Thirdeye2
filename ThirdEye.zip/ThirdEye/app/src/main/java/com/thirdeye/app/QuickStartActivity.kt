package com.thirdeye.app

import android.app.Activity
import android.content.Intent
import android.widget.Toast

/** Invisible launcher used by the tile and widget so the camera starts with an app window visible (Android's rule). */
class QuickStartActivity : Activity() {
    private var done = false
    override fun onResume() {
        super.onResume()
        if (done) return
        done = true
        if (Rec.state == "recording") Rec.stop(this)
        else when (val err = Rec.start(this)) {
            null -> {}
            "perm" -> { Toast.makeText(this, "Open Third Eye once to allow camera and microphone.", Toast.LENGTH_LONG).show(); startActivity(Intent(this, MainActivity::class.java)) }
            else -> Toast.makeText(this, err, Toast.LENGTH_LONG).show()
        }
        finish(); overridePendingTransition(0, 0)
    }
}
