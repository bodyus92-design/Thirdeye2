package com.thirdeye.app

import android.app.KeyguardManager
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** Optional app lock using the phone's own screen lock (PIN, pattern, fingerprint). */
open class LockedActivity : AppCompatActivity() {
    private var locked = false
    private val auth = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) { locked = false; Rec.unlockedAt = System.currentTimeMillis(); show(true) } else finishAndRemoveTask()
    }
    private fun show(v: Boolean) { findViewById<View>(android.R.id.content).visibility = if (v) View.VISIBLE else View.INVISIBLE }

    override fun onResume() {
        super.onResume()
        if (locked || !Rec.prefs(this).getBoolean("lock", false) || System.currentTimeMillis() - Rec.unlockedAt < 60_000) return
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) return
        locked = true; show(false)
        auth.launch(km.createConfirmDeviceCredentialIntent("Third Eye", "Confirm it's you"))
    }

    override fun onPause() { if (!locked && Rec.unlockedAt > 0) Rec.unlockedAt = System.currentTimeMillis(); super.onPause() }
}
