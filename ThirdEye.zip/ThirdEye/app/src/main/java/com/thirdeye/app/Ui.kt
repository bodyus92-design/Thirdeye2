package com.thirdeye.app

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.WindowCompat

object Ui {
    val TEAL = 0xFF1F9E8F.toInt(); val EMERALD = 0xFF2FBF8A.toInt(); val DEEP = 0xFF157A70.toInt()
    fun night(c: Context) = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    fun bg(c: Context) = if (night(c)) 0xFF17191A.toInt() else 0xFFF4F1EA.toInt()
    fun ink(c: Context) = if (night(c)) 0xFFE8EEEA.toInt() else 0xFF1F3A2E.toInt()
    fun sub(c: Context) = if (night(c)) 0xFF9AA8A2.toInt() else 0xFF6B7F74.toInt()
    fun surface(c: Context) = if (night(c)) 0xFF222627.toInt() else 0xFFFBF9F4.toInt()
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun applyTheme(c: Context) = AppCompatDelegate.setDefaultNightMode(
        when (Rec.prefs(c).getInt("theme", 0)) { 1 -> AppCompatDelegate.MODE_NIGHT_NO; 2 -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM })

    fun page(a: Activity, content: View, scroll: Boolean = false) {
        val root: View = if (scroll) ScrollView(a).apply { addView(content) } else content
        a.setContentView(root)
        root.setBackgroundColor(bg(a)); a.window.statusBarColor = bg(a); a.window.navigationBarColor = bg(a)
        WindowCompat.getInsetsController(a.window, root).apply { isAppearanceLightStatusBars = !night(a); isAppearanceLightNavigationBars = !night(a) }
    }

    fun txt(c: Context, t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(c).apply {
        text = t; textSize = sp; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun card(parent: LinearLayout): LinearLayout {
        val c = parent.context
        val b = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 10))
            background = GradientDrawable().apply { setColor(surface(c)); cornerRadius = dp(c, 20).toFloat() }
        }
        parent.addView(b, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(c, 12) })
        return b
    }

    fun seg(parent: LinearLayout, title: String, opts: List<String>, key: String, def: Int, onChange: () -> Unit = {}) {
        val c = parent.context; val p = Rec.prefs(c); val box = card(parent)
        box.addView(txt(c, title, 13f, sub(c)))
        val g = RadioGroup(c).apply { orientation = RadioGroup.HORIZONTAL }
        opts.forEachIndexed { i, o ->
            g.addView(RadioButton(c).apply { id = i + 1; text = o; setTextColor(ink(c)); textSize = 13f; buttonTintList = ColorStateList.valueOf(TEAL) },
                RadioGroup.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        g.check(p.getInt(key, def) + 1)
        g.setOnCheckedChangeListener { _, id -> p.edit().putInt(key, id - 1).apply(); onChange() }
        box.addView(g)
    }

    fun toggle(parent: LinearLayout, title: String, key: String, def: Boolean) {
        val c = parent.context; val p = Rec.prefs(c)
        card(parent).addView(SwitchCompat(c).apply {
            text = title; setTextColor(ink(c)); isChecked = p.getBoolean(key, def)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean(key, v).apply() }
        })
    }
}
