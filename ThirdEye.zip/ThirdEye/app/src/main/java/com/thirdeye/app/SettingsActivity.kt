package com.thirdeye.app

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : LockedActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 28)) }
        col.addView(Ui.txt(c, "Settings", 28f, Ui.ink(c), true).apply { setPadding(0, 0, 0, Ui.dp(c, 14)) })
        Ui.seg(col, "Camera", listOf("Back", "Front", "Both"), "cam", 0)
        Ui.seg(col, "Quality preset", listOf("Maximum", "Balanced", "Saver"), "preset", 0)
        Ui.seg(col, "Resolution", listOf("Preset", "4K", "1080p", "720p", "480p"), "res", 0)
        Ui.seg(col, "Frame rate", listOf("Auto", "30", "60"), "fps", 0)
        Ui.seg(col, "Auto-split files", listOf("Off", "5 min", "10 min", "20 min"), "seg", 0)
        Ui.seg(col, "Start delay", listOf("None", "5 s", "10 s"), "delay", 0)
        Ui.toggle(col, "Record sound", "mic", true)
        Ui.seg(col, "Theme", listOf("System", "Light", "Dark"), "theme", 0) { Ui.applyTheme(c) }
        Ui.toggle(col, "Haptic feedback", "haptic", true)
        Ui.toggle(col, "Reduce motion", "reduce", false)
        if (getSystemService(android.app.KeyguardManager::class.java).isDeviceSecure) Ui.toggle(col, "App lock (uses your phone's screen lock)", "lock", false)
        Ui.card(col).apply {
            addView(Ui.txt(c, "This phone", 13f, Ui.sub(c)))
            addView(Ui.txt(c, Caps.summary(c), 14f, Ui.ink(c)))
        }
        Ui.card(col).apply {
            addView(Ui.txt(c, "Battery: allow long recordings  ›", 16f, Ui.ink(c), true).apply { setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 10)) })
            setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        Ui.card(col).apply {
            addView(Ui.txt(c, "Quick Start", 13f, Ui.sub(c)))
            addView(Ui.txt(c, "Tile: swipe down twice, tap ✎, drag “Third Eye” into your tiles.\n\nWidget: long-press the home screen → Widgets → Third Eye.\n\nBoth use the settings above. Android may open Third Eye for a moment to start the camera. That is normal.", 14f, Ui.ink(c)))
        }
        Ui.card(col).apply {
            addView(Ui.txt(c, "Recordings  ›", 16f, Ui.ink(c), true).apply { setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 10)) })
            setOnClickListener { startActivity(Intent(c, LibraryActivity::class.java)) }
        }
        col.addView(Ui.txt(c, "Android always shows a notification and a camera indicator while recording. Videos stay on this phone. Only record where everyone has agreed.", 12f, Ui.sub(c)),
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        Ui.page(c, col, true)
    }
}
