package com.thirdeye.app

import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.camera2.CaptureRequest
import android.os.*
import android.provider.MediaStore
import android.util.Range
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ConcurrentCamera
import androidx.camera.core.UseCaseGroup
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : LifecycleService() {
    companion object { const val STOP = "STOP" }

    private val h = Handler(Looper.getMainLooper())
    private val vcs = ArrayList<VideoCapture<Recorder>>()
    private val recs = ArrayList<Recording>()
    private var pending = 0
    private var segOk = true
    private var stopping = false
    private var note: String? = null
    private var wake: PowerManager.WakeLock? = null
    private var part = 0; private var retries = 0
    private var lastNs = 0L; private var prevNs = -1L; private var stall = 0
    private val t0 = System.currentTimeMillis()
    private val splitter = Runnable { stopRecs() }
    private val thermal = PowerManager.OnThermalStatusChangedListener { s ->
        if (s >= PowerManager.THERMAL_STATUS_SEVERE) stopAll("The phone got too hot, so recording was stopped safely.")
    }
    // RecordGuard: if the recorder stops advancing for ~10 s, cut the part and start a fresh one.
    private val guard = object : Runnable {
        override fun run() {
            if (!stopping && recs.isNotEmpty()) {
                if (lastNs == prevNs) stall++ else stall = 0
                prevNs = lastNs
                if (stall >= 2) { stall = 0; stopRecs() }
            }
            h.postDelayed(this, 5000)
        }
    }

    override fun onCreate() { super.onCreate(); Rec.app = applicationContext }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        super.onStartCommand(i, f, id)
        if (i?.action == STOP) { stopAll(); return START_NOT_STICKY }
        if (wake != null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("te", "Third Eye", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif("Getting ready…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "thirdeye:rec").apply { acquire(6 * 60 * 60 * 1000L) }
        getSystemService(PowerManager::class.java).addThermalStatusListener(ContextCompat.getMainExecutor(this), thermal)
        val p = Rec.prefs(this)
        val delay = intArrayOf(0, 5, 10)[p.getInt("delay", 0)] * 1000L
        h.postDelayed({ bind(p) }, delay)
        h.postDelayed({ if (Rec.state == "starting") stopAll("The camera didn't start. Another app may be using it.") }, delay + 15000L)
        h.postDelayed(guard, delay + 10000L)
        return START_NOT_STICKY
    }

    private fun notif(text: String): Notification = NotificationCompat.Builder(this, "te")
        .setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Third Eye is recording").setContentText(text)
        .setOngoing(true).setUsesChronometer(true).setWhen(t0)
        .setContentIntent(PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        .addAction(0, "Stop", PendingIntent.getService(this, 0, Intent(this, RecorderService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE))
        .build()

    private fun qs(preset: Int, res: Int, dual: Boolean): QualitySelector {
        val q = if (dual) Quality.HD else when (res) {
            1 -> Quality.UHD; 2 -> Quality.FHD; 3 -> Quality.HD; 4 -> Quality.SD
            else -> return when (preset) {
                0 -> QualitySelector.from(Quality.HIGHEST)
                1 -> QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD))
                else -> QualitySelector.from(Quality.HD, FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))
            }
        }
        return QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))
    }

    private fun buildCapture(p: SharedPreferences, dual: Boolean): VideoCapture<Recorder> {
        val preset = p.getInt("preset", 0); val res = p.getInt("res", 0)
        val rb = Recorder.Builder().setQualitySelector(qs(preset, res, dual))
        if (res == 0 && !dual) {
            if (preset == 1) rb.setTargetVideoEncodingBitRate(8_000_000)
            if (preset == 2) rb.setTargetVideoEncodingBitRate(3_000_000)
        }
        val vb = VideoCapture.Builder(rb.build())
        val fps = p.getInt("fps", 0)
        if (fps > 0) { val f = if (fps == 1) 30 else 60; Camera2Interop.Extender(vb).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(f, f)) }
        return vb.build()
    }

    private fun bind(p: SharedPreferences) {
        if (stopping) return
        val cam = p.getInt("cam", 0)
        val sels = when (cam) {
            0 -> listOf(CameraSelector.DEFAULT_BACK_CAMERA)
            1 -> listOf(CameraSelector.DEFAULT_FRONT_CAMERA)
            else -> listOf(CameraSelector.DEFAULT_BACK_CAMERA, CameraSelector.DEFAULT_FRONT_CAMERA)
        }
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            try {
                vcs.clear()
                sels.forEach { _ -> vcs.add(buildCapture(p, cam == 2)) }
                val provider = fut.get(); provider.unbindAll()
                if (cam == 2) provider.bindToLifecycle(sels.indices.map { ConcurrentCamera.SingleCameraConfig(sels[it], UseCaseGroup.Builder().addUseCase(vcs[it]).build(), this) })
                else provider.bindToLifecycle(this, sels[0], vcs[0])
                next(p)
            } catch (e: Exception) { stopAll(if (cam == 2) "This phone couldn't open both cameras at once." else "Couldn't open the camera.") }
        }, ContextCompat.getMainExecutor(this))
    }

    @SuppressLint("MissingPermission")
    private fun next(p: SharedPreferences) {
        if (stopping) return
        h.removeCallbacks(splitter)
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        recs.clear(); pending = vcs.size; segOk = true
        part++; lastNs = 0L; prevNs = -1L; stall = 0
        getSystemService(NotificationManager::class.java).notify(1, notif("Part $part · tap to open, or Stop"))
        vcs.forEachIndexed { i, v ->
            val tag = if (vcs.size == 1) "" else if (i == 0) "_back" else "_front"
            val cv = ContentValues()
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, "ThirdEye_$ts$tag")
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ThirdEye")
            val o = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setContentValues(cv).setFileSizeLimit(3_800_000_000L).build()
            var pr = v.output.prepareRecording(this, o)
            if (i == 0 && p.getBoolean("mic", true)) pr = pr.withAudioEnabled()   // one audio track per session keeps sound in sync
            recs.add(pr.start(ContextCompat.getMainExecutor(this)) { e -> onEvent(e, i == 0, p) })
        }
        val m = intArrayOf(0, 5, 10, 20)[p.getInt("seg", 0)]
        if (m > 0) h.postDelayed(splitter, m * 60_000L)
    }

    private fun onEvent(e: VideoRecordEvent, primary: Boolean, p: SharedPreferences) {
        if (e is VideoRecordEvent.Status) {
            if (!primary) return
            val ns = e.recordingStats.recordedDurationNanos
            lastNs = ns
            if (ns > 0 && Rec.state != "recording") Rec.set("recording")   // real frames are being written
            if (Environment.getExternalStorageDirectory().usableSpace < 300_000_000L) stopAll("Storage is almost full. Your recording was saved.")
        } else if (e is VideoRecordEvent.Finalize) {
            if (e.error != VideoRecordEvent.Finalize.ERROR_NONE && e.error != VideoRecordEvent.Finalize.ERROR_FILE_SIZE_LIMIT_REACHED) segOk = false
            if (--pending > 0) return
            recs.clear()
            if (stopping) finish()
            else if (segOk) { retries = 0; next(p) }
            else if (++retries <= 3) h.postDelayed({ next(p) }, 1500)
            else stopAll("The camera stopped responding.")
        }
    }

    private fun stopRecs() { recs.toList().forEach { it.stop() } }

    private fun stopAll(why: String? = null) {
        if (stopping) return
        stopping = true; note = why; h.removeCallbacksAndMessages(null)
        if (recs.isNotEmpty()) stopRecs() else finish()
    }

    private fun finish() {
        h.removeCallbacksAndMessages(null)
        try { getSystemService(PowerManager::class.java).removeThermalStatusListener(thermal) } catch (_: Exception) {}
        wake?.let { if (it.isHeld) it.release() }
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) {}
        vcs.clear()
        stopForeground(STOP_FOREGROUND_REMOVE)
        val n = note
        if (n != null) getSystemService(NotificationManager::class.java).notify(2,
            NotificationCompat.Builder(this, "te").setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Third Eye stopped").setContentText(n).setAutoCancel(true).build())
        Rec.set(if (n != null) "failed" else "idle", n)
        stopSelf()
    }

    override fun onDestroy() { if (Rec.state != "failed") Rec.set("idle"); super.onDestroy() }
}
