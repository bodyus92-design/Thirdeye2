package com.thirdeye.app

import android.app.Application

class App : Application() {
    override fun onCreate() { super.onCreate(); Rec.app = this; Ui.applyTheme(this) }
}
