package com.thirdeye.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.util.concurrent.CopyOnWriteArraySet

/** One shared brain for the app, the Quick Settings tile and the widget. */
object Rec {
    @Volatile var state = "idle"   // idle | starting | recording | failed
    @Volatile var error: String? = null
    @Volatile var app: Context? = null
    @Volatile var unlockedAt = 0L
    val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun prefs(c: Context) = c.getSharedPreferences("te", Context.MODE_PRIVATE)

    fun set(s: String, e: String? = null) {
        state = s; error = e
        main.post { listeners.forEach { it() }; app?.let { QuickWidget.refresh(it) } }
    }

    fun missing(c: Context) = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        .filter { ContextCompat.checkSelfPermission(c, it) != PackageManager.PERMISSION_GRANTED }

    /** Shared readiness check + start. Returns null if OK/already running, "perm" if permissions are missing, else an error message. */
    fun start(c: Context): String? {
        app = c.applicationContext
        if (state == "starting" || state == "recording") return null
        if (missing(c).isNotEmpty()) return "perm"
        if (Environment.getExternalStorageDirectory().usableSpace < 500_000_000L) return "Not enough free storage (500 MB needed)."
        val cam = prefs(c).getInt("cam", 0)
        val need = when (cam) { 0 -> listOf(PackageManager.FEATURE_CAMERA); 1 -> listOf(PackageManager.FEATURE_CAMERA_FRONT)
            else -> listOf(PackageManager.FEATURE_CAMERA, PackageManager.FEATURE_CAMERA_FRONT) }
        if (need.any { !c.packageManager.hasSystemFeature(it) }) return "That camera isn't available on this device."
        if (cam == 2 && !Caps.dual(c)) return "This phone can't record with both cameras at once. Pick Back or Front in Settings."
        set("starting")
        return try { ContextCompat.startForegroundService(c, Intent(c, RecorderService::class.java)); null }
        catch (e: Exception) { set("failed", "Android didn't allow recording to start."); "Android didn't allow recording to start." }
    }

    fun stop(c: Context) { c.startService(Intent(c, RecorderService::class.java).setAction("STOP")) }
}
