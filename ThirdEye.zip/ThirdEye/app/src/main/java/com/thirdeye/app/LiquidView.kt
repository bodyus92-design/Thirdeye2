package com.thirdeye.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** The big liquid recording circle. */
class LiquidView(c: Context) : View(c) {
    var recording = false
    var busy = false
    var reduce = false
    private var phase = 0f
    private var press = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val path = Path()
    private val idle = ValueAnimator.ofFloat(0f, 6.2832f).apply {
        duration = 7000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!reduce) idle.start() }
    override fun onDetachedFromWindow() { idle.cancel(); super.onDetachedFromWindow() }

    private fun pressTo(down: Boolean) {
        ValueAnimator.ofFloat(press, if (down) 1f else 0f).apply {
            duration = 180; addUpdateListener { press = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> pressTo(true)
            MotionEvent.ACTION_UP -> { pressTo(false); performClick() }
            MotionEvent.ACTION_CANCEL -> pressTo(false)
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = min(width, height) * 0.34f * (1f - 0.07f * press)
        val boost = 1f + 2.2f * press + (if (busy) 1.2f else 0f)
        for (layer in 0..2) {
            val k = 1f + (2 - layer) * 0.09f
            val amp = (0.035f + 0.012f * layer) * boost
            path.reset()
            for (i in 0..72) {
                val a = i / 72f * 6.2832f
                val w = sin(3 * a + phase * (1 + layer)) + 0.6f * sin(5 * a - phase * 2)
                val rr = r * k * (1 + amp * w)
                val x = cx + rr * cos(a); val y = cy + rr * sin(a)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            if (layer < 2) { fill.shader = null; fill.color = if (recording) Ui.EMERALD else Ui.TEAL; fill.alpha = 40 + 30 * layer }
            else fill.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.4f, Ui.EMERALD, Ui.DEEP, Shader.TileMode.CLAMP)
            c.drawPath(path, fill)
        }
        if (recording) c.drawRoundRect(cx - r * .16f, cy - r * .16f, cx + r * .16f, cy + r * .16f, r * .05f, r * .05f, ink)
        else c.drawCircle(cx, cy, r * 0.13f, ink)
    }
}
