package com.thirdeye.app

import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.text.format.DateFormat
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged

class LibraryActivity : LockedActivity() {
    data class V(val id: Long, val name: String, val date: Long, val dur: Long, val size: Long) {
        val uri get() = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
    }
    private var all = listOf<V>()
    private var newest = true
    private var q = ""
    private lateinit var list: ListView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 20), 0) }
        col.addView(Ui.txt(c, "Recordings", 28f, Ui.ink(c), true))
        val search = EditText(c).apply { hint = "Search"; setSingleLine(); setTextColor(Ui.ink(c)); setHintTextColor(Ui.sub(c)); doOnTextChanged { t, _, _, _ -> q = t.toString(); show() } }
        col.addView(search)
        val sort = Ui.txt(c, "Newest first ⇅", 13f, Ui.TEAL, true).apply {
            setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8))
            setOnClickListener { newest = !newest; text = if (newest) "Newest first ⇅" else "Oldest first ⇅"; show() }
        }
        col.addView(sort)
        list = ListView(c).apply { divider = null }
        col.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        if (Rec.prefs(c).getBoolean("lock", false)) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        Ui.page(c, col)
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        val out = ArrayList<V>()
        contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE),
            "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("Movies/ThirdEye%"), null)?.use { k ->
            while (k.moveToNext()) out.add(V(k.getLong(0), k.getString(1), k.getLong(2), k.getLong(3), k.getLong(4)))
        }
        all = out; show()
    }

    private fun show() {
        val l = all.filter { it.name.contains(q, true) }.sortedBy { if (newest) -it.date else it.date }
        list.adapter = object : BaseAdapter() {
            override fun getCount() = l.size
            override fun getItem(i: Int) = l[i]
            override fun getItemId(i: Int) = l[i].id
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val x = l[i]; val c = this@LibraryActivity
                val row = LinearLayout(c).apply { setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8)); gravity = Gravity.CENTER_VERTICAL }
                val iv = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; tag = x.id }
                row.addView(iv, LinearLayout.LayoutParams(Ui.dp(c, 72), Ui.dp(c, 72)))
                val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(c, 14), 0, 0, 0) }
                col.addView(Ui.txt(c, x.name, 15f, Ui.ink(c), true))
                val d = if (x.dur == 0L) "Incomplete" else "%d:%02d".format(x.dur / 60000, x.dur / 1000 % 60)
                col.addView(Ui.txt(c, "${DateFormat.format("d MMM, HH:mm", x.date * 1000)} · $d · ${"%.0f".format(x.size / 1e6)} MB", 12f, Ui.sub(c)))
                row.addView(col)
                Thread { try { val bm = contentResolver.loadThumbnail(x.uri, Size(160, 160), null); iv.post { if (iv.tag == x.id) iv.setImageBitmap(bm) } } catch (_: Exception) {} }.start()
                row.setOnClickListener { play(x) }
                row.setOnLongClickListener { menu(x); true }
                return row
            }
        }
    }

    private fun play(x: V) = startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(x.uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))

    private fun menu(x: V) = AlertDialog.Builder(this).setTitle(x.name).setItems(arrayOf("Share", "Delete")) { _, i ->
        if (i == 0) startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, x.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
        else AlertDialog.Builder(this).setMessage("Delete this recording?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
            try { contentResolver.delete(x.uri, null, null); load() } catch (e: Exception) { Toast.makeText(this, "Couldn't delete this file.", Toast.LENGTH_LONG).show() }
        }.show()
    }.show()
}
