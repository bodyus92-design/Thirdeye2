package com.thirdeye.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class QuickTile : TileService() {
    private val l: () -> Unit = { refresh() }
    override fun onStartListening() { Rec.app = applicationContext; Rec.listeners.add(l); refresh() }
    override fun onStopListening() { Rec.listeners.remove(l) }

    override fun onClick() {
        if (Rec.state == "recording") { Rec.stop(this); return }
        val i = Intent(this, QuickStartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        else startActivityAndCollapse(i)
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (Rec.state == "idle" || Rec.state == "failed") Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        t.label = "Third Eye"
        t.subtitle = when (Rec.state) { "recording" -> "Recording"; "starting" -> "Starting…"; "failed" -> "Unavailable"; else -> "Ready" }
        t.updateTile()
    }
}
